<?php
require __DIR__.'/../app/bootstrap.php';
refresh_user();

if (!current_user()) {
    render_header('Sign in', 'admin');
    ?>
    <div class="auth-shell admin-auth">
        <div class="auth-art">
            <div class="art-orbit orbit-one"></div>
            <div class="art-orbit orbit-two"></div>
            <div class="art-document">OPS<span>ADMIN CONSOLE</span></div>
            <div class="art-caption"><span>PRINTING,</span><br>UNDER CONTROL.</div>
        </div>
        <div class="auth-panel">
            <div class="eyebrow">ADMIN ACCESS</div>
            <h1>Welcome to<br>the control room</h1>
            <p class="muted">Sign in to manage print jobs and accounts.</p>
            <form method="post" action="/login.php" class="form-stack">
                <input type="hidden" name="csrf" value="<?=e(csrf_token())?>">
                <label>Email address
                    <input type="email" name="email" required placeholder="admin@company.com">
                </label>
                <label>Password
                    <input type="password" name="password" required placeholder="Enter your password">
                </label>
                <button class="button button-admin button-wide">Sign in <span>→</span></button>
            </form>
        </div>
    </div>
    <?php
    render_footer();
    exit;
}

require_login('admin');

$counts = [];
foreach (['Pending', 'Processing', 'Completed', 'Cancelled'] as $s) {
    $stmt = db()->prepare('SELECT COUNT(*) FROM jobs WHERE status=?');
    $stmt->bind_param('s', $s);
    $stmt->execute();
    $counts[$s] = (int)$stmt->get_result()->fetch_column();
}

$usersCount = (int)db()->query('SELECT COUNT(*) FROM users')->fetch_column();
$jobs = db()->query("SELECT j.*, u.email FROM jobs j JOIN users u ON u.id = j.user_id WHERE j.status = 'Pending' ORDER BY j.created_at ASC LIMIT 8")->fetch_all(MYSQLI_ASSOC);

// Fetch the 10 most recent email logs
$emailLogs = [];
$tableCheck = db()->query("SHOW TABLES LIKE 'email_logs'");
if ($tableCheck && $tableCheck->num_rows > 0) {
    $emailLogs = db()->query("SELECT * FROM email_logs ORDER BY sent_at DESC LIMIT 10")->fetch_all(MYSQLI_ASSOC);
}

render_header('Dashboard', 'admin');
page_title('Dashboard', 'A quick overview of the print room.');
?>
<div class="stats-grid admin-stats">
    <a class="stat-card" href="/admin/jobs.php?status=Pending">
        <div class="stat-top"><span>Pending jobs</span><i class="stat-icon warm">◷</i></div>
        <div class="stat-number"><?=number_format($counts['Pending'])?></div>
        <div class="stat-foot"><span class="dot pending"></span> Awaiting review</div>
    </a>
    <a class="stat-card" href="/admin/jobs.php?status=Processing">
        <div class="stat-top"><span>Processing jobs</span><i class="stat-icon violet">↻</i></div>
        <div class="stat-number"><?=number_format($counts['Processing'])?></div>
        <div class="stat-foot"><span class="dot processing"></span> In the print queue</div>
    </a>
    <a class="stat-card" href="/admin/jobs.php?status=Completed">
        <div class="stat-top"><span>Completed jobs</span><i class="stat-icon green">✓</i></div>
        <div class="stat-number"><?=number_format($counts['Completed'])?></div>
        <div class="stat-foot"><span class="dot completed"></span> Ready for collection</div>
    </a>
    <a class="stat-card" href="/admin/jobs.php?status=Cancelled">
        <div class="stat-top"><span>Cancelled jobs</span><i class="stat-icon gray">×</i></div>
        <div class="stat-number"><?=number_format($counts['Cancelled'])?></div>
        <div class="stat-foot"><span class="dot cancelled"></span> No longer in queue</div>
    </a>
    <a class="stat-card">
        <div class="stat-top"><span>Users</span><i class="stat-icon blue">♙</i></div>
        <div class="stat-number"><?=number_format($usersCount)?></div>
        <div class="stat-foot">Registered client accounts</div>
    </a>
</div>

<!-- Pending jobs table -->
<div class="section-heading">
    <div>
        <div class="eyebrow">NEEDS ATTENTION</div>
        <h2>Pending jobs</h2>
        <p>Review incoming documents and decide what prints next.</p>
    </div>
    <a class="text-link" href="/admin/jobs.php?status=Pending">View all pending <span>→</span></a>
</div>
<div class="table-card">
    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>Job</th>
                    <th>Document</th>
                    <th>Client</th>
                    <th>Submitted</th>
                    <th>Status</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php if (!$jobs): ?>
                    <tr>
                        <td colspan="6">
                            <div class="empty-state">
                                <span>✓</span>
                                <strong>All caught up</strong>
                                <small>There are no pending jobs right now.</small>
                            </div>
                        </td>
                    </tr>
                <?php else: foreach ($jobs as $j): ?>
                    <tr>
                        <td class="job-id">#<?=str_pad((string)$j['id'], 5, '0', STR_PAD_LEFT)?></td>
                        <td>
                            <div class="file-cell">
                                <span class="file-icon">▤</span>
                                <span>
                                    <strong><?=e($j['original_name'])?></strong>
                                    <small><?=number_format($j['file_size'] / 1024, 0)?> KB · <?=e($j['paper_size'])?> · <?=e($j['colour_mode'])?></small>
                                </span>
                            </div>
                        </td>
                        <td><?=e($j['email'])?></td>
                        <td><?=e(date('M j, Y · g:i a', strtotime($j['created_at'])))?></td>
                        <td><?=status_badge($j['status'])?></td>
                        <td><a class="button button-small button-soft" href="/admin/job.php?id=<?=(int)$j['id']?>">View details</a></td>
                    </tr>
                <?php endforeach; endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Email audit log table -->
<div class="section-heading" style="margin-top: 2.5rem;">
    <div>
        <div class="eyebrow">COMMUNICATIONS AUDIT</div>
        <h2>Sent email logs</h2>
        <p>Record of all transactional notifications dispatched to clients.</p>
    </div>
</div>
<div class="table-card">
    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>Recipient</th>
                    <th>Subject</th>
                    <th>Related Job</th>
                    <th>Sent At</th>
                    <th>Delivery Status</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!$emailLogs): ?>
                    <tr>
                        <td colspan="5">
                            <div class="empty-state">
                                <span>✉</span>
                                <strong>No emails logged yet</strong>
                                <small>Outbound emails will automatically appear here once dispatched.</small>
                            </div>
                        </td>
                    </tr>
                <?php else: foreach ($emailLogs as $log): ?>
                    <tr>
                        <td><strong><?=e($log['recipient'])?></strong></td>
                        <td><?=e($log['subject'])?></td>
                        <td>
                            <?php if (!empty($log['job_id'])): ?>
                                <a class="text-link" href="/admin/job.php?id=<?=(int)$log['job_id']?>">#<?=str_pad((string)$log['job_id'], 5, '0', STR_PAD_LEFT)?></a>
                            <?php else: ?>
                                <span class="muted">—</span>
                            <?php endif; ?>
                        </td>
                        <td><?=e(date('M j, Y · g:i a', strtotime($log['sent_at'])))?></td>
                        <td>
                            <?php if (strtolower($log['status']) === 'sent'): ?>
                                <span class="dot completed"></span> <?=e($log['status'])?>
                            <?php else: ?>
                                <span class="dot cancelled"></span> <?=e($log['status'])?>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php
render_footer();
